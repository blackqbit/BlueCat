
#include <linux/module.h>
#include <linux/kernel.h>

char *my_string = "dummy";
int my_int = 0;

MODULE_PARM(my_string,"s");
MODULE_PARM(my_int,"i");

int init_module(void)
{
    printk ("<1>Hello %s, you are number %d\n", my_string, my_int);
    return 0;
}

void cleanup_module(void)
{
    printk ("<1>Goodbye cruel world\n");
}

