/*
    Driver functions for the "thermostat"
*/
int initAD (void);
unsigned int readAD (unsigned int channel);
void closeAD (void);

void setDigOut (unsigned int bit);
void clearDigOut (unsigned int bit);
unsigned int getDigOut (unsigned int bit);
/*
	For simulation
*/
#ifdef DRIVER
#define SHM_KEY 1234		// shared memory key
typedef struct {
	unsigned int a2d;
	unsigned int leds;
	pid_t pid;
} shmem_t;
#endif

#define HEATER 	1
#define ALARM	2

