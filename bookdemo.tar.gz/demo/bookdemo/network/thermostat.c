/*

        File: thermostat.c

    This version of thermostat connects to a network allowing any client to
    get the current temperature and change operating parameters.
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <sys/shm.h>

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "driver.h"

typedef struct {
    unsigned setpoint;
    unsigned limit;
    unsigned deadband;
    unsigned value;
    int running;
} param_t;
// A param_t structure is set up in shared memory
static param_t *p;

#define setpoint    p->setpoint
#define limit       p->limit
#define deadband    p->deadband
#define value       p->value
#define running     p->running
#define PARAM_KEY   1217

int client_socket;

void done (int sig)
/*
    Signal handler to stop the program gracefully
*/
{
    running = 0;
}

void sendOK (void)
/*
    Reply to a parameter setting command
*/
{
    write (client_socket, "OK\n", 3);
}

void monitor (int pid)
{
    param_t *p;
    char in_text[40], out_text[10], *cmd;
    static const char *delims = " \t,=";
    int id;

// Initialize and attach shared memory region
    if ((id = shmget ((key_t) PARAM_KEY, sizeof (param_t), 0666)) == -1)
    {
        perror ("shmget in monitor");
        exit (1);
    }
    if ((p = (param_t *) shmat (id, (void *) 0, 0)) == (param_t *) -1)
    {
        perror ("shmat in monitor");
        exit (2);
    }
    while (1)
    {
    // Wait for a command and parse it
        read (client_socket, in_text, sizeof (in_text));
        cmd = strtok (in_text, delims);

        while (cmd)
        {
            switch (*cmd)
            {
                case 's':
                    setpoint = atoi (strtok (NULL, delims));
                    sendOK();
                    break;
                case 'l':
                    limit = atoi (strtok (NULL, delims));
                    sendOK();
                    break;
                case 'd':
                    deadband = atoi (strtok (NULL, delims));
                    sendOK();
                    break;
                case '?':
                    sprintf (out_text, "%d\n", value);
                    write (client_socket, out_text, strlen (out_text));
                    break;
                case 'q':   // close this connection
                    write (client_socket, "Closing connection\n", 19);
                    close (client_socket);
                    exit (0);

                default:
                    write (client_socket, "???\n", 4);
            }
            cmd = strtok (NULL, delims);
        }
    }
    exit (0);
}

void server (void)
/*
    This process is spawned by the thermostat to act as a network server.
    When it accepts a connection it spawns a monitor process.
*/
{
    int server_socket, client_len, pid;
    struct sockaddr_in server_addr, client_addr;

// Create unnamed socket and give it a "name"
    server_socket = socket (PF_INET, SOCK_STREAM, 0);
    server_addr.sin_family = AF_INET;
    if (inet_aton (SERVER, &server_addr.sin_addr) == 0)
    {
        printf ("inet_aton failed\n");
        exit (1);
    }
    server_addr.sin_port = htons (4242);

// Bind to the socket
    if (bind (server_socket, (struct sockaddr *) &server_addr, sizeof (server_addr)) != 0)
    {
        perror ("bind");
        exit (1);
    }

// Create a client queue
    if (listen (server_socket, 1) != 0)
    {
        perror ("listen");
        exit (1);
    }
    printf ("Network server running\n");

// Now we wait for connection requests
    while (1)
    {
        client_len = sizeof (client_addr);
        client_socket = accept (server_socket, (struct sockaddr *) &client_addr, &client_len);
        printf ("Connection established to %s\n", inet_ntoa (client_addr.sin_addr));

        switch (pid = fork())
        {
            case -1:
                perror ("fork in server");
                close (client_socket);
                break;
            case 0:
                monitor ();

            default:
                printf ("Starting new monitor process, pid = %d\n", pid);
        }
    }
}

int main (int argc, char *argv[])
/*
    This is the thermostat state machine.  It spawns the network server process
    that accepts client connections.
*/
{
    unsigned int i = 0, t, alarm = 0;
    enum state_t {OK, LOW, LIMIT} state = OK;
    unsigned int wait;
    int id;

    signal (SIGINT, done);  // set up signal handler
    if (argc > 1)           // get wait time
        sscanf (argv[1], "%d", &t);
    else
        t = 2;

    if (initAD() < 0)
    {
        printf ("Couldn't initialize A/D converter\n");
        exit (1);
    }
// Initialize and attach shared memory region shared between this process
// and the monitor.
    if ((id = shmget ((key_t) PARAM_KEY, sizeof (param_t), 0666 | IPC_CREAT)) == -1)
    {
        perror ("shmget in thermostat");
        return 1;
    }
    if ((p = (param_t *) shmat (id, (void *) 0, 0)) == (param_t *) -1)
    {
        perror ("shmat in thermostat");
        return 2;
    }
    setpoint = 32;
    limit = 45;
    deadband = 2;
    wait = t;
    running = 1;

    switch (fork())
    {
        case -1:
            perror ("fork in thermostat");
            exit (2);
        case 0:             // child
            server();
            break;
        default:            // parent
            while (running)
            {
                sleep (1);
                if (t++ >= wait)
                {
                    value = readAD(0);
                    printf ("Sample %d = %d\n", i, value);
                    i++;
                    t = 0;
                }
                switch (state)
                {
                    case OK:
                        if (value > limit)
                        {
                            state = LIMIT;
                            alarm = 1;
                            setDigOut (ALARM);
                        }
                        else if (value < setpoint - deadband)
                        {
                            state = LOW;
                            setDigOut (HEATER);
                        }
                        break;

                    case LOW:
                        if (value > limit)
                        {
                            state = LIMIT;
                            alarm = 1;
                            clearDigOut (HEATER);
                            setDigOut (ALARM);
                        }
                        else if (value > setpoint + deadband)
                        {
                            state = OK;
                            clearDigOut (HEATER);
                        }
                        break;

                    case LIMIT:
                        if (value < limit)
                        {
                            state = OK;
                            alarm = 0;
                            clearDigOut (ALARM);
                        }
                        else    // blink the alarm indicator
                            alarm ? (alarm = 0) : (alarm = 1);
                        if (alarm)
                            setDigOut (ALARM);
                        else
                            clearDigOut (ALARM);
                        break;
                }
            }
            closeAD();
    }
    return 0;
}
