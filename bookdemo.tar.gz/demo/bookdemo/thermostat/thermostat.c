/*

        File: thermostat.c

    A program to control a "heater" and limit alarm based on data from
    a simulated A to D converter. The current A/D reading is sent
    to stdout.
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>

#include "driver.h"

unsigned int setpoint, limit, deadband;
extern int errno;

int running = 1;

void done (int sig)
/*
    Signal handler to stop the program gracefully
*/
{
    running = 0;
}

int main (int argc, char *argv[])
{
    unsigned int i = 0, t, alarm;
    enum state_t {OK, LOW, LIMIT} state = OK;
    unsigned int wait, value;

    signal (SIGINT, done);  // set up signal handler
    if (argc > 1)           // get wait time
        sscanf (argv[1], "%d", &t);
    else
        t = 2;

    if (initAD() < 0)
    {
        printf ("Couldn't initialize A/D converter\n");
        exit (1);
    }
    setpoint = 32;
    limit = 45;
    deadband = 2;
    wait = t;

    while (running)
    {
        sleep (1);
        if (t++ >= wait)
        {
            value = readAD(0);
            printf ("Sample %d = %d\n", i, value);
            i++;
            t = 0;
        }
        switch (state)
        {
            case OK:
                if (value > limit)
                {
                    state = LIMIT;
                    alarm = 1;
                    setDigOut (ALARM);
                }
                else if (value < setpoint - deadband)
                {
                    state = LOW;
                    setDigOut (HEATER);
                }
                break;

            case LOW:
                if (value > limit)
                {
                    state = LIMIT;
                    alarm = 1;
                    clearDigOut (HEATER);
                    setDigOut (ALARM);
                }
                else if (value > setpoint + deadband)
                {
                    state = OK;
                    clearDigOut (HEATER);
                }
                break;

            case LIMIT:
                if (value < limit)
                {
                    state = OK;
                    alarm = 0;
                    clearDigOut (ALARM);
                }
                else    // blink the alarm indicator
                    alarm ? (alarm = 0) : (alarm = 1);
                if (alarm)
                    setDigOut (ALARM);
                else
                    clearDigOut (ALARM);
                break;
        }
    }
    closeAD();
    return 0;
}
