/*

        File: monitor.c

    A program to monitor console input for parameter changes

*/
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#ifdef SIM
#include <sys/shm.h>
#endif
#include "measure.h"

int cli_socket, running = 1;

void done (int sig)
/*
    Signal handler to stop the program gracefully
*/
{
    running = 0;
}

void sendOK (void)
{
    write (cli_socket, "OK\n", 3);
}

const char *delims = " \t,=";

int main (int argc, char *argv[])
{
    int serv_socket, cli_len;
    struct sockaddr_in serv_addr, cli_addr;
    params_t *p;
    char in_text[80], out_text[40], *cmd;
    int id;
    int len, result;

    signal (SIGINT, done);  // set up signal handler
#ifdef SIM
/*
    Get the shared memory identifier and attach to it
*/
    if ((id = shmget ((key_t) PARAM_KEY, sizeof (params_t), 0666)) < 0)
    {
        printf ("Can't get shared memory region\n");
        return 1;
    }
    if ((p = (params_t *) shmat (id, (void *) 0, 0)) == (params_t *) -1)
    {
        printf ("Can't attach shared memory region\n");
        return 2;
    }
#else
    sscanf (argv[1], "%x", &p);
#endif
// Create unnamed socket and then name it
    serv_socket = socket (AF_INET, SOCK_STREAM, 0);
    serv_addr.sin_family = AF_INET;
    result = inet_aton (SERVER, &serv_addr.sin_addr);
    if (result == 0)
    {
        perror ("inet_aton error");
        exit (1);
    }
// Bind to the socket
    serv_addr.sin_port = htons (4242);
    bind (serv_socket, (struct sockaddr *) &serv_addr, sizeof (serv_addr));

// Create a client queue
    listen (serv_socket, 1);
    printf ("Network server running\n");

// Accept a connection
    cli_len = sizeof (cli_addr);
    cli_socket = accept (serv_socket, (struct sockaddr *) &cli_addr, &cli_len);
    printf ("Connection established\n");

    while (running)
    {
        len = read (cli_socket, in_text, sizeof (in_text));
        cmd = strtok (in_text, delims);

        while (cmd)
        {
            switch (*cmd)
            {
                case 's':
                    p->setpoint = atoi (strtok (NULL, delims));
                    sendOK();
                    break;
                case 'l':
                    p->limit = atoi (strtok (NULL, delims));
                    sendOK();
                    break;
                case 'd':
                    p->deadband = atoi (strtok (NULL, delims));
                    sendOK();
                    break;
                case 'w':
                    p->wait = atoi (strtok (NULL, delims));
                    sendOK();
                    break;
                case 'g':
                    sprintf (out_text, "Current value = %d\n", p->value);
                    write (cli_socket, out_text, strlen (out_text));
                    break;
                case 'q':
                    sprintf (out_text, "Breaking connection\n");
                    write (cli_socket, out_text, strlen (out_text));
                    running = 0;
                    break;
                default:
                    write (cli_socket, "???\n", 4);
            }
            cmd = strtok (NULL, delims);
        }
    }
#ifdef SIM
    shmdt (p);          // Detach shared memory region
#endif
    return 0;
}