/*

        File: monitor.c

    A program to monitor console input for parameter changes

*/
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#ifdef SIM
#include <sys/shm.h>
#endif
#include "measure.h"

int running = 1;

void done (int sig)
/*
    Signal handler to stop the program gracefully
*/
{
    running = 0;
}

const char *delims = " \t,=";

int main (int argc, char *argv[])
{
    params_t *p;
    char text[80], *cmd;
    int id;
    unsigned int value;

    signal (SIGINT, done);  // set up signal handler
#ifdef SIM
/*
    Get the shared memory identifier and attach to it
*/
    if ((id = shmget ((key_t) PARAM_KEY, sizeof (params_t), 0666)) < 0)
    {
        printf ("Can't get shared memory region\n");
        return 1;
    }
    if ((p = (params_t *) shmat (id, (void *) 0, 0)) == (params_t *) -1)
    {
        printf ("Can't attach shared memory region\n");
        return 2;
    }
#else
    sscanf (argv[1], "%x", &p);
#endif
    while (running)
    {
        gets (text);
        cmd = strtok (text, delims);

        while (cmd)
        {
            value = atoi (strtok (NULL, delims));
            switch (*cmd)
            {
                case 's':
                    p->setpoint = value;
                    break;
                case 'l':
                    p->limit = value;
                    break;
                case 'd':
                    p->deadband = value;
                    break;
                default:
            }
            cmd = strtok (NULL, delims);
        }
    }
#ifdef SIM
    shmdt (p);          // Detach shared memory region
#endif
    return 0;
}