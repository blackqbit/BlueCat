/*

    parport.c

    A bare bones parallel port device driver to support the thermostat
    example in "Hands-on Embedded and Real-time Linux".

    This driver makes several simplifying assumptions:
        It only supports one parallel port located at BASE.

*/
#include <linux/module.h>
#include <linux/version.h>
#include <linux/kernel.h> /* printk() */
#include <linux/fs.h>     /* everything... */
#include <linux/errno.h>  /* error codes */
#include <linux/slab.h>
#include <linux/mm.h>
#include <linux/ioport.h>
#include <asm/io.h>
#include <asm/uaccess.h>

#define BASE    0x378
#define NPORTS  8
/*
 * Open and close
 */
int parport_open (struct inode *inode, struct file *filp)
{
    MOD_INC_USE_COUNT;
    return 0;          /* success */
}

int parport_release (struct inode *inode, struct file *filp)
{
    MOD_DEC_USE_COUNT;
    return 0;
}
/*
   Data transfer: read and write
 */
ssize_t parport_read (struct file *filp,
                char *buf, size_t count, loff_t *f_pos)
/*
    Returns a combination of the data register and the status register
    Low Byte    Data Register
    High Byte   Status Register
*/
{
    char local[2];
    size_t local_count = count;

    if (local_count--)          // make sure count is not zero
    {
        local[0] = inb (BASE);  // Data port
        if (local_count)        // Get status port too?
        {
            char temp = inb (BASE + 1); // Status port
            local[1] = ~temp & 0x7f;    // Invert so pushed button = 1
            temp &= 0x80;               // but high order bit is already inverted
            local[1] |= temp;
        }
        if (copy_to_user (buf, local, count & 3))
            return -EFAULT;
    }
    return count;
}

ssize_t parport_write (struct file *filp,
                const char *buf, size_t count, loff_t *f_pos)
/*
    Writes 'buf' to the Data port
*/
{
    char *plocal, *ptr;
    char local[2];
    size_t local_count = count;

    if (count > 2)
	plocal = kmalloc (count, GFP_KERNEL);
    else
	plocal = local;

    if (!plocal)
        return -ENOMEM;
    if (copy_from_user (plocal, buf, count))
	    return -EFAULT;
    ptr = plocal;

    while (local_count--)
    {
        outb (*ptr++, BASE);
    }
    if (count > 2)
    	kfree (plocal);
    return count;
}

struct file_operations parport_ops = {
    NULL,	        // owner
    NULL,           // lseek
    parport_read,
    parport_write,
    NULL,           // readdir
    NULL,           // poll
    NULL,           // ioctl
    NULL,           // mmap
    parport_open,
    NULL,	        // flush
    parport_release,
                   /* nothing more, fill with NULLs */
};
/*
   Finally, the module stuff
*/

int init_module (void)
{
    int result;
/*
    Get NPORTS I/O ports starting at BASE
*/
    result = check_region (BASE, NPORTS);
	if (result)
	{   int base = BASE;
	    printk (KERN_INFO "parport: can't get I/O port address 0x%x\n", base);
	    return result;
	}
	request_region (BASE, NPORTS, "parport");
/*
   Register the major device number
*/
    result = register_chrdev (6, "parport", &parport_ops);
    if (result < 0)
    {
        printk (KERN_WARNING "parport: can't register device\n");
   	    release_region (BASE, NPORTS);
        return result;
    }
    return 0;       /* success  */
}

void cleanup_module (void)
{
    unregister_chrdev (6, "parport");
   	release_region (BASE, NPORTS);
}

