/*

        file: trgdrive.c

    Target driver functions for "thermostat" example
    This implementation uses pushbuttons connected to parallel port status
    lines to raise and lower the indicated "temperature".
*/

#include "driver.h"
#include <unistd.h>
#include <fcntl.h>

// Pushbutton definitions
#define DOWN    0x20
#define UP      0x40
#define FAST    0x80

// Temperature increments
#define SLOW_INC    2
#define FAST_INC    3       // This is in addition to the SLOW_INC

#define INIT_TEMP   35      // Gotta start somewhere

static int port;

int initAD (void)
/*
    Opens parport as a pseudo A to D converter.
    Return value is -1 if open fails.
*/
{
    if ((port = open ("/dev/parport", O_RDWR)) < 0)
        return -1;
    return 0;
}

unsigned int readAD (unsigned int channel)
/*
    'channel' is not used in this version
*/
{
    static int temp = INIT_TEMP;
    unsigned char in[2];

    read (port, in, 2);
    if (in[1] & DOWN)
    {
        temp -= SLOW_INC;
        if (in[1] & FAST)
            temp -= FAST_INC;
    }
    if (in[1] & UP)
    {
        temp += SLOW_INC;
        if (in[1] & FAST)
            temp += FAST_INC;
    }
    return temp;
}

void closeAD (void)
/*
    Close the connection to parport
*/
{
    close (port);
}

void setDigOut (unsigned int bit)
/*
    Set bit mask 'bit' in parport's data register.
*/
{
    unsigned char data;

    read (port, &data, 1);
    data |= bit;
    write (port, &data, 1);
}

void clearDigOut (unsigned int bit)
/*
    Clear bit mask 'bit' in parport's data register.
*/
{
    unsigned char data;

    read (port, &data, 1);
    data &= ~bit;
    write (port, &data, 1);
}

